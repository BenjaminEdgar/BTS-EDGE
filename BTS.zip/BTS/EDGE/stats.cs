﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDGE
{
    public static class stats
    {
        public static int Points = 0;
        public static int FPS = 0;

        public static int CalcFPS = 0;
    }
}
